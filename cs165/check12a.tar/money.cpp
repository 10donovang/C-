/***********************
 * File: money.cpp
 ***********************/

#include <iostream>
#include <iomanip>
using namespace std;

#include "money.h"

/*****************************************************************
 * Function: prompt
 * Purpose: Asks the user for values for dollars and cents
 *   and stores them.
 ****************************************************************/
void Money :: prompt()
{
   int dollars;
   int cents;

   cout << "Dollars: ";
   cin >> dollars;

   cout << "Cents: ";
   cin >> cents;

   setDollars(dollars);
   setCents(cents);
}

/*****************************************************************
 * Function: display
 * Purpose: Displays the value of the money object.
 ****************************************************************/
void Money :: display() const 
{
   cout << "$" << dollars << ".";
   cout << setfill('0') << setw(2) << cents << endl;
}

ostream & operator << (ostream & out, const Money & rhs)
{
  out << "$" << rhs.getDollars() << "."
      << setfill('0') << setw(2) << rhs.getCents();
  return out;
}

bool operator == (const Money & lhs, const Money & rhs)
{
  return (lhs.getDollars() == rhs.getDollars() &&
	  lhs.getCents() == rhs.getCents());
}

bool operator != (const Money & lhs, const Money & rhs)
{
  int tempDol1 = lhs.getDollars();
  int tempDol2 = rhs.getDollars();
  int tempCen1 = lhs.getCents();
  int tempCen2 = rhs.getCents();
  if(tempDol1 != tempDol2 || tempCen1 != tempCen2)
    return true;
  else
  return false;
}
